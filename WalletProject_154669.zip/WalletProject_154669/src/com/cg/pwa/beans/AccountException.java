package com.cg.pwa.beans;

public class AccountException extends Exception {
public AccountException(String s){
	super(s);
}
}
